use projects
db.createUser({user:'nimda',pwd:"nimda321",roles:[{role:"dbAdmin",db:"projects"}]})