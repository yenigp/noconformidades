'use strict';

var publicPath  = 'public';
var privatePath = 'private';

exports.public = publicPath;
exports.private = privatePath;