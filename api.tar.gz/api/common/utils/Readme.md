## Description files
- `paths.js` contains a shortcut to a public paths files/folders
- `logger.js` contains a winston set configuration for logging
- `process-images.js` contains actions to process images from base 64 via db
- `validations.js` contains a list of regex
- `init-on-modules.js` contain the logic to register all the models contained in modules folder