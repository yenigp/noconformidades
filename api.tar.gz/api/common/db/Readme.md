## files description

- index.js run sequelize pending migrations and exec the models association
- processImagesHooks.js contains a list of column names that will be defined as file
  and will allow create the file in a public folder and save the name in db.