'use strict';

var lodash = require('lodash');
var jsonAPI = require('../../../common/utils').jsonAPI;

module.exports = function (req, res) {
  var SystemLog = global.app.orm.mongoose.model('SystemLog');

  var jsonAPIBody = {
    meta: {
      pagination: {}
    },
    data: []
  };

  var query = jsonAPI.buildQueryFromReqForMongoose({
    req: req,
    model: SystemLog
  });
  return SystemLog
    .find(query.where)
    .limit(query.limit)
    .skip(query.offset)
    .sort(query.order)
    .exec()
    .then(function (data) {
      jsonAPIBody.data = data;
      jsonAPIBody.meta.pagination.count = data.length;
      return SystemLog.countDocuments(query.where);
    })
    .then(function (count) {
      jsonAPIBody.meta.pagination.total = count;
      res.status(200).json(jsonAPIBody); // OK.
    })
    .catch(function (error) {
      global.app.logger.error(error, {
        module: 'logs/system/index',
        submodule: 'routes',
        stack: error.stack
      });
      res.status(500).json(jsonAPI.processErrors(error, req, { file: __filename }));
    });
};