'use strict';

var mongoose = global.app.orm.mongoose;
var Schema = mongoose.Schema;

exports.loadModel = function loadModel() {
  console.log("cargando log de mongo")
  var SystemLogSchema = new Schema({
    timestamp: {
      type: Date,
      default: Date.now
    },
    username: {
      type: String
    },
    cargo: {
      type: String
    },
    PersonId: {
      type: Number
    },
    hasUser: {
      type: Boolean
    },
    path: {
      type: String
    },
    method: {
      type: String
    },
    protocol: {
      type: String
    },
    host: {
      type: String
    },
    query: {
      type: Object
    },
    body: {
      type: Object
    },
    headers: {
      type: Object
    },
    error: {
      type: Object
    },
    wasFinished: {
      type: Boolean
    },
    delay: {
      type: Number
    },
    statusCode: {
      type: Number
    },
    response: {
      type: Object
    }
  }, {
    collection: 'SystemLogs'
  });

  class LogClass {
    getRequest() {
      var template = `var request = require("request");
        var util=require("util")
        var options = { 
          method: '${this.method.toUpperCase()}',
          url: '${this.protocol}://${this.host}${this.path}',
          qs: ${this.query},
          headers: ${this.headers},
          body: ${this.body},
          json: true 
        };
        delete options.headers['accept-encoding'];
        request(options, function (error, response, body) {
          if (error) throw new Error(error);
          console.log(util.inspect(body,{depth:null}));
        });
        `;
      return template;
    }
    getFileName() {

    }

  }

  SystemLogSchema.loadClass(LogClass);

  mongoose.model('SystemLog', SystemLogSchema);
};