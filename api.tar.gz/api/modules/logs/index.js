'use strict';


exports.loadModels = function loadModels() {
  return;
  // global.loadMongo = function () {
    require('./models/system-log').loadModel();
  // }
};

exports.setRoutes = function setRoutes() {
  return;
  var apiPrefix = global.app.config.get('api:prefix');
  var adminLogsRoute = apiPrefix + '/admin/logs';


  global.app.express
    .route(adminLogsRoute)
    .get(
      global.app.security.ensureAuthenticated(),
      require('./routes/index'));

};